package com.example.theappguruz.sqlitedemoandroid;

/**
 * Created by Nikunj on 03-09-2015.
 */
public class Constants {
    public static final int ADD_RECORD = 0;
    public static final int UPDATE_RECORD = 1;
    public static final String DML_TYPE = "DML_TYPE";
    public static final String UPDATE = "Update";
    public static final String INSERT = "Insert";
    public static final String DELETE = "Delete";
    public static final String FIRST_NAME = "Firstname";
    public static final String LAST_NAME = "Lastname";
    public static final String ID = "ID";
}
